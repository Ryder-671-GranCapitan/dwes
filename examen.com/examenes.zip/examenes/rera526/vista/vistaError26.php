<?php

namespace rera526\vista;

    use Exception;
    use rera526\util\Html;

    class VistaError26 {
        public function muestraError(Exception $excepcion) : void {
            Html::inicio("Reseña", ['/rera526/estilos/formulario.css', '/rera526/estilos/general.css', '/rera526/estilos/tablas.css']);

            $file = $excepcion->getFile();
            $components = explode("/", $file);
            $script = end($components);
            $modelo = rtrim($script, ".php");

            echo "<h1>Error</h1>";
            echo "<p>Error message {$excepcion->getMessage()}</p>";
            echo "<p>Error Code {$excepcion->getCode()}</p>";
            echo "<p>Model {$modelo}</p>";
            echo "<p>Line {$excepcion->getLine()}</p>";

            echo "<p><a href='insertar26.php'>Volver al inicio</a></p>";

            Html::fin();
        }
    }
?>