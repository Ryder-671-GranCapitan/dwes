<?php

namespace rera526\vista;

use recupera526\entidad\Resena26;

use rera526\util\Html;

class VistaResena26
{
    public function enviarSalida($reseña)
    {
        Html::inicio('resultado', ['/rera526/estilos/general.css', '/rera526/estilos/formulario.css', '/rera526/estilos/tablas.css']);
?>
        <h1>detalles de la reseña <?= $reseña->id_resena ?></h1>
        <table>
            <thead>
                <tr>
                    <th>Id_Reseña</th>
                    <th>NIF</th>
                    <th>Fecha</th>
                    <th>Clasificacion</th>
                    <th>Comentario</th>
                </tr>
            </thead>

            <tbody>
                <td>
                    <th><?=$reseña->id_resena?></th>
                    <th><?=$reseña->nif?></th>
                    <th><?=$reseña->fecha->format(Resena26::FECHA_USUARIO)?></th>
                    <th><?=$reseña->clasificacion?></th>
                    <th><?=$reseña->comentario?></th>
                </td>
            </tbody>
        </table>


<?php



        Html::fin();
    }
}

?>