<?php
namespace rera526\modelo;

use DateTime;
use rera526\entidad\Resena26;
use Exception;
use PDO;

class ModeloResena26 {
    private const TABLA = 'reseña';
    private const PK = 'id_reseña';

    protected PDO $pdo;

    public function __construct() {
        $dsn = 'mysql:host=cpd.iesgrancapitan.org;port=9992;dbname=tiendaol;charset=utf8mb4';
        $usuario = 'usuario';
        $clave = 'usuario';
        $options = [
            PDO::ATTR_CASE => PDO::CASE_LOWER,
            PDO::ATTR_EMULATE_PREPARES => false,
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
        ];

        $this->pdo = new PDO($dsn, $usuario, $clave, $options);
    }

    public function procesaPeticion (){

        $nif = $_POST['nif'] ? $_POST['nif'] : '' ;
        $nif = filter_var($nif, FILTER_SANITIZE_SPECIAL_CHARS);
        
        $referencia = $_POST['referencia'] ? $_POST['referencia'] : '';
        $referencia = filter_var($referencia, FILTER_SANITIZE_SPECIAL_CHARS);
        
        $fecha = $_POST['fecha'];

        $clasificacion = $_POST['clasificacion'] ;
        $clasificacion = filter_var($clasificacion, FILTER_VALIDATE_INT);

        $comentario = $_POST['comentario'] ? $_POST['comentario'] : '';
        $comentario = filter_var($comentario, FILTER_SANITIZE_SPECIAL_CHARS);

        
        if (!$fecha) {
            throw new Exception("Error, no hay fecha de la reseña", 2);
        }
        if (!$clasificacion) {
            throw new Exception("Error, no hay clasificacion de la reseña", 2);
        }

        $sql = "INSERT INTO ". self::TABLA. " VALUES(null, :nif, :referencia, :fecha, :clasificacion, :comentario)";

        $stmt = $this->pdo->prepare($sql);

        $param = [
            ':nif' => $nif,
            ':referencia' => $referencia,
            ':fecha' => $fecha,
            ':clasificacion' => $clasificacion,
            ':comentario' => $comentario
        ];

        $stmt->execute($param);

        $data = $stmt->fetch();

        if (!$data) {
            throw new Exception("error en la consulta", 3);            
        }

        $resena = new Resena26($data);
        return $resena;
    }
}


?>