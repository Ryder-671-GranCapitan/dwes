<?php
namespace rera526\controlador;

use Exception;
use rera526\vista\VistaError26;

class Controlador26{
    private array $peticiones;
    public function __construct() {
         $this->peticiones = [
                'insertarResena' => [
                    'modelo' => 'rera526\\modelo\\ModeloResena07',
                    'vista' => 'rera526\\vista\\VistaResena07'
                ]
            ];
    }

    public function procesaPeticion()  {
        try {
            $idp = $_POST['idp'] ? $_POST['idp'] : '';
            $idp = filter_var($idp, FILTER_SANITIZE_SPECIAL_CHARS);

            if (!class_exists($this->peticiones[$idp]['modelo'])) {
                throw new Exception("modelo desconocido", 4);
            }

            if(!class_exists($this->peticiones[$idp]['vista'])){
                throw new Exception("vista desconocida",4);                
            }

            $classModelo = $this->peticiones[$idp]['modelo'];
            $classVista = $this->peticiones[$idp]['vista'];

            $instanciaModelo = new $classModelo();
            $data = $instanciaModelo->procesaPeticion();

            $instanciaVista = new $classVista;
            $instanciaVista->enviarSalida($data);

            
        } catch (Exception $e) {
            $error = new VistaError26();
            $error->muestraError($e);
        }
    }
}


?>