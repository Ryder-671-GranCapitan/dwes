<?php

namespace exra526\controlador;

use Exception;
use exra526\vista\VistaError26;
use rera526\vista\VistaError26 as VistaVistaError26;

class Controlador26
{
    protected array $peticiones;

    public function __construct()
    {
        $this->peticiones = [
            'buscarPedido' => [
                'modelo' => 'exra26\\modelo\\ModeloPedido26',
                'vista' => 'exra26\\vista\\VistaPedido26'
            ]
        ];
    }

    public function gestionaPeticion() {
        try {
            $idp = $_POST['idp'] ?? '';
            $idp = filter_var($idp, FILTER_SANITIZE_SPECIAL_CHARS);

            if (!class_exists($this->peticiones[$idp]['modelo'])) {
                throw new Exception("modelo no encontrado", 1);
            }
            if (!class_exists($this->peticiones[$idp]['vista'])) {
                throw new Exception("Vista no encontrada", 1);
            }

            $clase_modelo = $this->peticiones[$idp]['modelo'];
            $clase_vista = $this->peticiones[$idp]['vista'];
            
            $instancia_modelo = new $clase_modelo;
            $data = $instancia_modelo->procesaPeticion();

            $instancia_vista = new $clase_vista;
            $instancia_vista->enviarSalida($data);

        } catch (Exception $e) {
            $instancia = new VistaError26;
            $instancia->muestraError($e);
        }
        
    }
}
