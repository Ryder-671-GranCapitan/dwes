<?php

use exra526\util\Html;


Html::inicio("Reseña", ['/rera526/estilos/formulario.css', '/rera526/estilos/general.css', '/rera526/estilos/tablas.css']);

    ?>
    <form action="index26.php" method="post">
        <label for="n_pedido">numero pedido</label>
        <input type="text" name="n_pedido" id="n_pedido" required>
        <button type="submit" name="idp" id="idp" value="idp">buscar</button>
    </form>
    
    <?php

Html::fin()
?>
