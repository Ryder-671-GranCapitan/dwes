<?php

namespace exra526\vista;

use exra526\entidad\EntidadPedido26;
use exra526\util\Html;

class vistaPedido26
{
    public function FunctionName($data)
    {
        Html::inicio("Reseña", ['/exra526/estilos/formulario.css', '/exra526/estilos/general.css', '/exra526/estilos/tablas.css']);
?>
        <table>
            <thead>
                <tr>
                    <th>npedido</th>
                    <th>nif</th>
                    <th>fecha</th>
                    <th>observaciones</th>
                    <th>total_pedido</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td><?= $data->n_pedido?></td>
                    <td><?=$data->nif?></td>
                    <td><?=$data->fecha->format(EntidadPedido26::FECHA_USUARIO)?></td>
                    <td><?=$data->observaciones?></td>
                    <td><?=$data->total_pedido?></td>
                </tr>
            </tbody>
        </table>

<?php
        Html::fin();
    }
}
