<?php

namespace exra526\entidad;

use Exception;
use ReflectionProperty;
use DateTime;

class EntidadPedido26
{

    public const FECHA_MYSQL = "Y-m-d H:i:s";
    public const FECHA_USUARIO = "d/m/Y H:i:s";


    protected int $n_pedido;
    protected string $nif;
    protected DateTime $fehca;
    protected ?string $observaciones;
    protected ?int $total_pedido;

    public function __construct(array $datos)
    {
        foreach ($datos as $propiedad => $valor) {
            $this->__set($propiedad, $valor);
        }
    }

    public static function getPropiedad($objeto, $propiedad)
    {
        $instancia = new ReflectionProperty($objeto, $propiedad);
        return $instancia->getType()->getName();
    }
    public function __set($name, $value)
    {
        if (!property_exists($this, $name)) {
            throw new Exception("propiedad desconocida", 2);
        }

        if (self::getPropiedad($name, $value) == DateTime::class) {
            $this->$name = new DateTime($value);
        } else {
            $this->$name = $value;
        }
    }

    public function __get($name)
    {
        if (!property_exists($this, $name)) {
            throw new Exception("propiedad desconocida", 2);
        }
        return $this->$name;
    }
}
