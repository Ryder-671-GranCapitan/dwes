<?php

  require("funciones.php");

  function f2() {
    echo "Function f2";
  }

?>