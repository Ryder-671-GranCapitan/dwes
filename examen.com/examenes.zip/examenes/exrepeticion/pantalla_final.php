<?php

session_start();

echo "<p>Bienvenido a la pantalla final. Se ha comenzado a comprar el dia : " . $_SESSION['fecha'] . "</p>";


?>