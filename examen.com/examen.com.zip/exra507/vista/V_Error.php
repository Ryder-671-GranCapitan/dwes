<?php
    namespace exra507\vista;
    use Exception;

    class V_Error extends Exception {
        
    }
?>