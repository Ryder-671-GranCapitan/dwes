<?php
    class AutoCargaClases {
        
    }
?>