USE CliniCan;


DELETE FROM Perros;



INSERT INTO Perros VALUES 
('111A', 'Chispita', 'Pastor alemán',     "2018-01-01"),
('111B', 'Colega',   'Pastor belga',      "2018-02-01"),
('111C', 'Boby',     'Pastor inglés',     "2018-01-01"),
('222A', 'Lunes',    'Yorkshire terrier', "2018-03-01"),
('222B', 'Lara',     'Yorkshire terrier', "2018-01-01"),
('333A', 'Boby',     'Beagle',            "2018-02-01"),
('444A', 'Chucho',   'Caniche',           "2018-01-01"),
('555A', 'Linux',    'Beagle',            "2018-01-01"),
('555B', 'Windows',  'Yorkshire terrier', "2018-03-01"),
('666A', 'Chucho',   'Caniche',           "2018-01-01"),
('777A', 'Linux',    'Beagle',            "2018-01-01"),
('777B', 'Windows',  'Yorkshire terrier', "2018-03-01")
;

