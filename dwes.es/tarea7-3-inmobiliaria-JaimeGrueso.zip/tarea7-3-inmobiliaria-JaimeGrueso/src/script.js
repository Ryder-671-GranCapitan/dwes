document.addEventListener('DOMContentLoaded', function () {
    // Llamada inicial para cargar zonas
    loadZones();

    // Asociar el evento "submit" al formulario
    document.querySelector('.formInmo').addEventListener('submit', handleSearch);

    /**
     * Valida un DNI español (8 dígitos + letra)
     */
    function validateDNI(dni) {
        const letterValue = "TRWAGMYFPDXBNJZSQVHLCKE";
        const dniRegex = /^[0-9]{8}[TRWAGMYFPDXBNJZSQVHLCKE]$/i;

        if (!dniRegex.test(dni)) return false;

        const number = dni.substring(0, 8);
        const letter = dni.charAt(8).toUpperCase();
        const calculatedLetter = letterValue.charAt(number % 23);

        return letter === calculatedLetter;
    }

    /**
     * Carga las zonas desde php/zonas.php y las añade a un <select>
     */
    async function loadZones() {
        try {
            const response = await fetch('php/zonas.php');
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            const contentType = response.headers.get('content-type');
            if (!contentType || !contentType.includes('application/json')) {
                throw new TypeError('Expected JSON response');
            }

            const data = await response.json();
            if (!data || !Array.isArray(data.data)) {
                throw new Error('Invalid data structure received');
            }

            const zonaSelect = document.getElementById('zona');
            zonaSelect.innerHTML = '<option value="">Seleccione una zona</option>';

            data.data.forEach(zona => {
                const option = document.createElement('option');
                option.value = zona.idzona;
                option.textContent = zona.descripcion;
                zonaSelect.appendChild(option);
            });

        } catch (error) {
            console.error('Error loading zones:', error);
            const zonaSelect = document.getElementById('zona');
            zonaSelect.innerHTML = '<option value="">Error cargando zonas</option>';
        }
    }


    /**
     * Maneja la búsqueda de inmuebles al hacer submit en el formulario
     */
    async function handleSearch(e) {
        e.preventDefault();

        const tbody = document.querySelector('tbody');
        const capaGrabar = document.querySelector('.capaGrabar');

        try {
            // Recoger valores del formulario
            const dni = document.getElementById('dni').value;
            let zona = document.getElementById('zona').value;
            const habitaciones = document.querySelector('input[name="numhab"]:checked')?.value;
            const precio = document.getElementById('precio').value;

            // Validar campos obligatorios
            if (!dni || !zona || !habitaciones || !precio) {
                alert('Todos los campos son obligatorios');
                return;
            }

            // Validar el DNI
            if (!validateDNI(dni)) {
                alert('DNI no válido');
                return;
            }

            // Validar que la zona no sea "undefined"
            if (!zona || zona === "undefined") {
                console.error("Error: Zona no seleccionada.");
                alert("Por favor, selecciona una zona válida.");
                return;
            }

            const url = `php/inmuebles.php?zona=${encodeURIComponent(zona)}&habitaciones=${encodeURIComponent(habitaciones)}&precio=${encodeURIComponent(precio)}`;
            console.log('Buscando inmuebles en:', url);

            const response = await fetch(url);
            const contentType = response.headers.get('content-type');
            let errorMessage = 'Error desconocido';

            if (!response.ok) {
                try {
                    const errorData = await response.json();
                    errorMessage = errorData.error || `Error del servidor: ${response.status}`;
                } catch (e) {
                    errorMessage = `Error del servidor: ${response.status}`;
                }
                throw new Error(errorMessage);
            }

            if (!contentType || !contentType.includes('application/json')) {
                throw new Error('Respuesta del servidor no es JSON válido');
            }

            const data = await response.json();

            if (!data || !Array.isArray(data.data)) {
                throw new Error('Estructura de datos inválida en la respuesta');
            }

            // Limpiamos la tabla antes de llenarla
            tbody.innerHTML = '';

            if (data.data.length === 0) {
                tbody.innerHTML = '<tr><td colspan="3" class="text-center">No se encontraron inmuebles</td></tr>';
                return;
            }

            // Rellenar la tabla con los inmuebles recibidos
            data.data.forEach(inmueble => {
                const tr = document.createElement('tr');
                tr.setAttribute('data-id', inmueble.idinmuebles); // Changed from idinmueble to idinmuebles
                tr.innerHTML = `
                    <td>${inmueble.idinmuebles}</td>
                    <td>${inmueble.domicilio}</td>
                    <td>${inmueble.precio}€</td>
                `;
                tr.addEventListener('click', function() {
                    this.classList.toggle('selected');
                    console.log('Row selected:', this.getAttribute('data-id'));
                    const selectedCount = document.querySelectorAll('tbody tr.selected').length;
                    console.log('Selected rows:', selectedCount);
                });
                tbody.appendChild(tr);
            });

            if (data.data.length > 0) {
                const dniValue = document.getElementById('dni').value;
                capaGrabar.innerHTML = `
                    <button type="button" class="btn btn-primary" id="btnReservar">Grabar Reservas</button>
                `;
                const btnReservar = document.getElementById('btnReservar');
                btnReservar.addEventListener('click', () => {
                    console.log('Botón clickeado'); // Debug
                    console.log('DNI a enviar:', dniValue); // Debug
                    handleReservation(dniValue);
                });
            } else {
                capaGrabar.innerHTML = '';
            }

        } catch (error) {
            console.error('Error searching properties:', error);
            
            tbody.innerHTML = `
                <tr>
                    <td colspan="3" class="text-center text-danger">
                        Error al buscar inmuebles: ${error.message}
                    </td>
                </tr>`;
            
            capaGrabar.innerHTML = '';
            
            alert(`Error: ${error.message}`);
        }
    }

    /**
     * Maneja la reserva de los inmuebles seleccionados en la tabla
     */
    async function handleReservation(dni) {
        console.log('handleReservation llamado con DNI:', dni); // Debug
        
        const selectedRows = document.querySelectorAll('tbody tr.selected');
        console.log('Filas seleccionadas:', selectedRows.length); // Debug
        
        if (selectedRows.length === 0) {
            alert('Seleccione al menos un inmueble');
            return;
        }
    
        try {
            for (let row of selectedRows) {
                const inmuebleId = row.getAttribute('data-id');
                console.log('Enviando petición para inmueble:', inmuebleId); // Debug
                
                const requestBody = {
                    dni: dni,
                    idinmueble: inmuebleId  // This matches the reservas table column name
                };
                console.log('Datos a enviar:', requestBody); // Debug
    
                const response = await fetch('php/reservas.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(requestBody)
                });
    
                console.log('Respuesta recibida:', response.status); // Debug
                const data = await response.json();
                console.log('Datos recibidos:', data); // Debug
    
                if (!response.ok || !data.success) {
                    throw new Error(data.error || 'Error al realizar la reserva');
                }
            }
    
            alert('¡Reservas realizadas con éxito!');
            document.querySelector('.formInmo').reset();
            document.querySelector('tbody').innerHTML = '';
            document.querySelector('.capaGrabar').innerHTML = '';
            await loadZones();
    
        } catch (error) {
            console.error('Error en la reserva:', error);
            alert(`Error al realizar la reserva: ${error.message}`);
        }
    }
});
