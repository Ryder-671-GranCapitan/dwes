# Inmobiliaria - Proyecto de Gestión Inmobiliaria

## Cambios Realizados

### Archivos SQL
- Se modificó `inmobiliaria.sql` para incluir las claves foráneas (FOREIGN KEYS) necesarias
- Se corrigió la estructura de las tablas para permitir las relaciones entre:
  - `inmuebles` y `zonas`
  - `reservas` e `inmuebles`
- Se añadieron las restricciones de integridad referencial

### Archivos PHP
- **connection.php**: 
  - Mejorado el manejo de errores
  - Añadida validación de conexión
  - Configuración de charset a UTF-8

- **zonas.php**:
  - Corregida la consulta SQL
  - Añadido manejo de respuestas JSON
  - Mejorado el manejo de errores

- **inmuebles.php**:
  - Corregidos los nombres de las columnas en las consultas
  - Añadida validación de parámetros
  - Mejorado el filtrado de inmuebles disponibles

- **reservas.php**:
  - Corregida la estructura de la tabla
  - Añadida validación de DNI
  - Mejorado el proceso de inserción de reservas

### JavaScript (script.js)
- Corregido el manejo de respuestas del servidor
- Implementada la selección múltiple de inmuebles
- Mejorado el sistema de reservas
- Añadida validación de formularios
- Corregidos los nombres de las columnas al procesar datos

### HTML/CSS
- Añadidos estilos para filas seleccionadas
- Mejorada la estructura del formulario
- Añadida validación de campos

## Problemas Resueltos
1. **Datos Indefinidos**: 
   - Se corrigieron los nombres de las columnas en las consultas SQL
   - Se añadió validación de datos en las respuestas JSON

2. **Relaciones entre Tablas**:
   - Se agregaron las claves foráneas necesarias
   - Se implementó la integridad referencial

3. **Validación de Datos**:
   - Se añadió validación de DNI
   - Se implementó validación de parámetros en consultas

4. **Manejo de Errores**:
   - Se mejoró el sistema de logs
   - Se implementaron mensajes de error más descriptivos

## Mejoras Implementadas
- Mejor gestión de errores
- Interfaz más intuitiva
- Sistema de selección múltiple
- Validación de datos más robusta
- Mejor manejo de respuestas del servidor

## Autor
- **Nombre**: Jaime Grueso Martin