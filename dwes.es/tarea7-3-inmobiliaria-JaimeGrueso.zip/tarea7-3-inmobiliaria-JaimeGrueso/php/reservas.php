<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once "connection.php";

header('Content-Type: application/json; charset=utf-8');

try {
    // Obtener datos del POST
    $jsonData = file_get_contents('php://input'); // Corregido el path
    error_log("Datos recibidos: " . $jsonData); // Debug
    
    $data = json_decode($jsonData);

    if (!$data || !isset($data->dni) || !isset($data->idinmueble)) {
        throw new Exception('Faltan datos requeridos');
    }

    // Debug
    error_log("DNI: " . $data->dni);
    error_log("ID Inmueble: " . $data->idinmueble);

    // Verificar que el inmueble no esté ya reservado
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM reservas WHERE idinmueble = :idinmueble");
    $stmt->execute([':idinmueble' => $data->idinmueble]);
    
    if ($stmt->fetchColumn() > 0) {
        throw new Exception('El inmueble ya está reservado');
    }

    // Insertar la reserva
    $stmt = $pdo->prepare("INSERT INTO reservas (dni, idinmueble, fecha) VALUES (:dni, :idinmueble, CURDATE())");
    $result = $stmt->execute([
        ':dni' => $data->dni,
        ':idinmueble' => $data->idinmueble
    ]);

    if (!$result) {
        throw new Exception('Error al insertar la reserva');
    }

    echo json_encode([
        'success' => true,
        'message' => 'Reserva realizada con éxito'
    ]);

} catch (PDOException $e) {
    error_log("Error de base de datos: " . $e->getMessage());
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'Error en la base de datos: ' . $e->getMessage()
    ]);
} catch (Exception $e) {
    error_log("Error general: " . $e->getMessage());
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
}