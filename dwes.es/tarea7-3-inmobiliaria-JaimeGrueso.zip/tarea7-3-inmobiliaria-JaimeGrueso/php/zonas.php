<?php
require_once "connection.php";

header('Content-Type: application/json; charset=utf-8');

try {
    $stmt = $pdo->prepare("SELECT idzona, descripcion FROM zonas ORDER BY descripcion");
    $stmt->execute();
    echo json_encode(['data' => $stmt->fetchAll(PDO::FETCH_ASSOC)]);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['error' => $e->getMessage()]);
}

$pdo = null;
exit();