SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

DROP SCHEMA IF EXISTS inmobiliaria;
CREATE SCHEMA inmobiliaria DEFAULT CHARACTER SET utf8;
USE inmobiliaria;

-- Tabla Zonas
CREATE TABLE IF NOT EXISTS `zonas` (
  `idzona` SMALLINT(5) UNSIGNED NOT NULL AUTO_INCREMENT,
  `descripcion` VARCHAR(50) NOT NULL,
  PRIMARY KEY (`idzona`)
) ENGINE=InnoDB DEFAULT CHARACTER SET latin1 COLLATE latin1_spanish_ci;

-- Tabla Inmuebles
CREATE TABLE IF NOT EXISTS `inmuebles` (
  `idinmuebles` SMALLINT(5) UNSIGNED NOT NULL AUTO_INCREMENT,
  `zona` SMALLINT(5) UNSIGNED NOT NULL,
  `domicilio` VARCHAR(50) NOT NULL,
  `habitaciones` SMALLINT(1) UNSIGNED NOT NULL,
  `precio` SMALLINT(6) UNSIGNED NOT NULL,
  PRIMARY KEY (`idinmuebles`),
  FOREIGN KEY (`zona`) REFERENCES `zonas`(`idzona`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARACTER SET latin1 COLLATE latin1_spanish_ci;

-- Tabla Reservas
CREATE TABLE IF NOT EXISTS `reservas` (
  `idreservas` SMALLINT(5) UNSIGNED NOT NULL AUTO_INCREMENT,
  `dni` VARCHAR(9) NOT NULL,
  `idinmueble` SMALLINT(5) UNSIGNED NOT NULL,
  `fecha` DATE NOT NULL DEFAULT CURRENT_DATE,
  PRIMARY KEY (`idreservas`),
  FOREIGN KEY (`idinmueble`) REFERENCES `inmuebles`(`idinmuebles`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARACTER SET latin1 COLLATE latin1_spanish_ci;

-- Insertar Datos en la tabla Zonas
INSERT INTO `zonas` (`idzona`, `descripcion`) VALUES
(1, "Centro"),
(2, "Ciudad Jardin"),
(3, "Centro Historico"),
(4, "San Andres"),
(5, "San Lorenzo"),
(6, "Santa Marina"),
(7, "Vallellano");

-- Insertar Datos en la tabla Inmuebles
INSERT INTO `inmuebles` (`idinmuebles`, `zona`, `domicilio`, `habitaciones`, `precio`) VALUES
(1, 2, "C/Pintor, 2", 2, 200),
(2, 3, "C/Rosa, 45", 1, 350),
(3, 1, "C/Cántaro, 32", 3, 500),
(4, 6, "C/El molino, 57", 4, 350),
(5, 1, "C/El olmo", 1, 350),
(6, 4, "C/Pelayo", 3, 450),
(7, 5, "C/Sandogal, 6", 4, 650),
(8, 2, "C/El Peral, 7", 2, 150),
(9, 7, "C/El Naranjo, 121", 4, 370),
(10, 2, "C/Soria, 80", 2, 550);
