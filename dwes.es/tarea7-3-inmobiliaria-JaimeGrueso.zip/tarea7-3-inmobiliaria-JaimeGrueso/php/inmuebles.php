<?php
require_once "connection.php";

header('Content-Type: application/json; charset=utf-8');

try {
    if (!isset($_GET['zona']) || !isset($_GET['habitaciones']) || !isset($_GET['precio'])) {
        throw new Exception('Faltan parámetros requeridos');
    }

    $zona = filter_var($_GET['zona'], FILTER_VALIDATE_INT);
    $habitaciones = filter_var($_GET['habitaciones'], FILTER_VALIDATE_INT);
    $precio = filter_var($_GET['precio'], FILTER_VALIDATE_FLOAT);

    // Updated SQL query to use correct column names
    $sql = "SELECT idinmuebles, domicilio, precio 
            FROM inmuebles 
            WHERE zona = :zona 
            AND habitaciones = :habitaciones 
            AND precio <= :precio 
            AND idinmuebles NOT IN (SELECT idinmueble FROM reservas)";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        ':zona' => $zona,
        ':habitaciones' => $habitaciones,
        ':precio' => $precio
    ]);

    echo json_encode(['data' => $stmt->fetchAll(PDO::FETCH_ASSOC)]);

} catch (PDOException $e) {
    error_log("Database error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['error' => 'Error en la base de datos: ' . $e->getMessage()]);
} catch (Exception $e) {
    error_log("General error: " . $e->getMessage());
    http_response_code(400);
    echo json_encode(['error' => $e->getMessage()]);
}